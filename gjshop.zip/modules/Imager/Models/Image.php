<?php

namespace Modules\Imager;

use Illuminate\Database\Eloquent\Model;
/**
 * Description of Image
 *
 * @author dinhtrong
 */
class Image extends  Model{
   
}
