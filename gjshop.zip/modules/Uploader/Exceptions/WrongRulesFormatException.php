<?php

namespace Modules\Uploader\Exceptions;

/**
 * Description of WrongRulesFormatException
 *
 * @author dinhtrong
 */
class WrongRulesFormatException extends \Exception{
    //put your code here
}
