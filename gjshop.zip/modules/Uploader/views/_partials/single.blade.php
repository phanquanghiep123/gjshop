<div class="uploader single">
    <input type="file" name="{{$name}}" onchange="Uploader.singleUpload(this)" />
    <div class="preview">
        
    </div>
</div>
