<?php

namespace Modules\Shop\Exceptions;

use Exception;

/**
 * Description of ItemNotAvailable
 *
 * @author dinhtrong
 */
class ItemNotAvailable extends Exception {
}
