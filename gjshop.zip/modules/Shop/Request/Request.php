<?php

namespace Modules\Shop\Request;

use App\Http\Requests\Request as BaseRequest;

/**
 * Description of Request
 *
 * @author dinhtrong
 */
abstract class Request extends BaseRequest {
   
}
