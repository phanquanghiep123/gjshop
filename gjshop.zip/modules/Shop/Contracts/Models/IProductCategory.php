<?php

namespace Modules\Shop\Models;

/**
 *
 * @author dinhtrong
 */
interface IProductCategory {
    //put your code here
}
