<?php

namespace Modules\Shop\Models;

/**
 *
 * @author dinhtrong
 */
interface IProduct {
    const ACTIVED_STATUS = 1;
    const DEACTIVE_STATUS = 0;
}
