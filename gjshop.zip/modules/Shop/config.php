<?php

return [
    'layout' => 'layouts.frontend',
    'checkout' => 'layouts.checkout',
    'shop_categories' => 'layouts.shop_categories',
    'backend_layout' => 'layouts.backend',
    'middleware' => ['web']
];
