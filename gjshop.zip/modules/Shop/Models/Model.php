<?php

namespace Modules\Shop\Models;

use Illuminate\Database\Eloquent\Model as BaseModel;

/**
 * Description of Model
 *
 * @author dinhtrong
 */
class Model extends BaseModel {
    
}
