<?php

namespace Modules\Shop;

/**
 * Description of Shop
 *
 * @author dinhtrong
 */
class Shop {
    public static function getRootDir(){
        return __DIR__;
    }
}
