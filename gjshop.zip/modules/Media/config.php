<?php

return array(
    'middleware' => ['web','admin'],
    'route_prefix' => 'nfladmin',
    'base_path' => public_path('uploads')
);
