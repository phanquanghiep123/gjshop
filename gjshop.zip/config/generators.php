<?php

return [
	'template_path' => base_path('resources/pingpong/generators/stubs')
];